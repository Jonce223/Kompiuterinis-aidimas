import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level13 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level13 extends World
{

    /**
     * Constructor for objects of class Level13.
     * 
     */
    public Level13()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        ground500 ground500 = new ground500();
        addObject(ground500,747,190);
        ground100 ground100 = new ground100();
        addObject(ground100,396,260);
        ground100 ground1002 = new ground100();
        addObject(ground1002,242,194);
        ground100 ground1003 = new ground100();
        addObject(ground1003,48,192);
        Pug pug = new Pug();
        addObject(pug,886,131);
        Enemies enemies = new Enemies();
        addObject(enemies,601,125);
        Enemies enemies2 = new Enemies();
        addObject(enemies2,730,123);
        Enemies enemies3 = new Enemies();
        addObject(enemies3,232,126);
        Enemies enemies4 = new Enemies();
        addObject(enemies4,43,123);
        colider colider = new colider();
        addObject(colider,1,152);
        CounterEnemies counter = new CounterEnemies();
        addObject(counter, 820, 29);
        Counter counter1 = new Counter();
        addObject(counter1, 858, 32);
        Health health = new Health();
        addObject(health,75,13);
    }
}
