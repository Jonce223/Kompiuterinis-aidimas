import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level27 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level27 extends World
{

    /**
     * Constructor for objects of class level27.
     * 
     */
    public level27()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        plonas plonas = new plonas();
        addObject(plonas,822,360);
        Moving50 moving50 = new Moving50();
        addObject(moving50,534,360);
        Moving50 moving502 = new Moving50();
        addObject(moving502,250,361);
        plonas plonas2 = new plonas();
        addObject(plonas2,77,298);
        Pug pug = new Pug();
        addObject(pug,876,313);

        spikes spikes = new spikes();
        addObject(spikes,450,488);
        spikes900_down spikes900_down = new spikes900_down();
        addObject(spikes900_down,448,10);
        Health health = new Health();
        addObject(health,77,16);
       CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);
        colider colider = new colider();
        addObject(colider,1,268);
       
    }
}
