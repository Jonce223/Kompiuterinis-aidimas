import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Pug extends Actor
{ 
    private int vSpeed  = 0;
    private int acceleration = 2;
    private boolean jumping;
    private int jumpStrength = 23;
    private int jumpCount = 10;
  
    private int direction = 1;
    private int shootingCounter = 0;
    private int hitTime = 0;
    
    private int verticalSpeed = 0;
    private int movementSpeed = 2;
    private int frame = 1;
    private int animationCountRight = 0;
    private int animationCountLeft = 0;
    private int fallAcceleration = 1;
    private boolean shooting = false;
    
   //Garsai
   public GreenfootSound soundtrack = new GreenfootSound("Naujamuzika.mp3");
   private GreenfootSound saudymo = new GreenfootSound("Saudymo.wav");
 
    //Paveiksliukai
    private GreenfootImage jump_right = new GreenfootImage("pug_suolis_i_desine.png");
    private GreenfootImage jump_left = new GreenfootImage("pug_suolis_i_kaire.png");
    
    private GreenfootImage standing_left = new GreenfootImage("pug_i_kaire.png");
    private GreenfootImage standing_right = new GreenfootImage("pug_i_desine.png");
    
    
    private GreenfootImage saudymasLeft = new GreenfootImage("saudymasikaire.png");
    private GreenfootImage saudymasRight = new GreenfootImage("saudymasidesine.png");
    
    private GreenfootImage run_right1 = new GreenfootImage("pug_i_desine.png");
    private GreenfootImage run_right2 = new GreenfootImage("ejimasidesine.png");
    private GreenfootImage run_right3 = new GreenfootImage("ejimasidesine2.png");
    private GreenfootImage run_right4 = new GreenfootImage("pug_i_desine.png");
    
    private GreenfootImage run_left1 = new GreenfootImage("pug_i_kaire.png");
    private GreenfootImage run_left2 = new GreenfootImage("ejimasikaire.png");
    private GreenfootImage run_left3 = new GreenfootImage("ejimasikaire2.png");
    private GreenfootImage run_left4 = new GreenfootImage("pug_i_kaire.png");
    
    public static int playerHealth = 3;
    
    
    public void act() 
    {
        //Spikes---
        checkRightSpikes();
        checkLeftSpikes();
        onSpikes();
        //-------------
        platformAbove();
        checkFall();
        checkRightWalls();
        checkLeftWalls();
        shooting();
        isHit();
        
        jumpCount--;
        checkKey();
        animationCountRight++;
        animationCountLeft++;
        shootingCounter--;
        
        if(Greenfoot.isKeyDown("right")){
            setLocation(getX()+5, getY());
            moveRight();
            direction = 1;
        }
        
        if("right".equals(Greenfoot.getKey())){
            stop();
        }
        
        if("left".equals(Greenfoot.getKey())){
            stop();
        }
        
        if("space".equals(Greenfoot.getKey())){
            stop();
        }
        
        if(Greenfoot.isKeyDown("left")){
            setLocation(getX()-5, getY());
            moveLeft();
            direction = -1;
        }
        
        
    }
    
    public void stop(){
        if(direction == 1){
            setImage(standing_right);
        }
        else
            setImage(standing_left);
         
        
    }
    
    public boolean shooting()
    {
        if(Greenfoot.isKeyDown("c") && shootingCounter <= 0 && direction == 1)
        {
           saudymo.play();
           setImage(saudymasRight);
       
           getWorld().addObject(new shootRight(), getX() + 70, getY());
           shootingCounter = 20;
           return true;
            
        }
        
         if(Greenfoot.isKeyDown("c") && shootingCounter <= 0 && direction == -1)
        {
           saudymo.play();
           setImage(saudymasLeft);
           getWorld().addObject(new shootLeft(), getX() - 70, getY());
           shootingCounter = 20;
           return true;
            
            
        }
        return false;
    }
    
    public void moveRight()
    {
        setLocation(getX() + movementSpeed, getY());
        
        if(jumping != true){
           if(animationCountRight % 4 == 0){
               runRight();
           } 
        } 
    }
    
    public void runRight(){
        if(frame == 1){
            setImage(run_right1);
        }
        
        if(frame == 2){
            setImage(run_right2);
        }
        
        if(frame == 3){
            setImage(run_right3);
        }
        
        if(frame == 4){
            setImage(run_right4);
            frame = 1;
            return;
        }
        frame++;
        
    }
    
    public void moveLeft()
    {
        setLocation(getX() - movementSpeed, getY());
        
        if(jumping != true){
           if(animationCountLeft % 4 == 0){
               runLeft();
           } 
        } 
    }
    
    public void runLeft(){
        if(frame == 1){
            setImage(run_left1);
        }
        
        if(frame == 2){
            setImage(run_left2);
        }
        
        if(frame == 3){
            setImage(run_left3);
        }
        
        if(frame == 4){
            setImage(run_left4);
            frame = 1;
            return;
        }
        frame++;
        
    }
  
    public void checkKey()
    {
        if(Greenfoot.isKeyDown("space") && jumping == false)
        {
            if(jumpCount <= 0){
                jump();
                jumpCount = 15;
                
            }
            
        }
            
    }
    
    public int isHit(){
    Actor player = getOneObjectAtOffset((int)getImage().getWidth()/2, 0, BadGuy.class);
       
    if(player != null){
        if(animationCountRight % 6 == 0){
         playerHealth--;
         hitTime = 50;
        }
         
        if(playerHealth == 0){
           Greenfoot.setWorld(new GameOver());
           Greenfoot.playSound("Game Over.mp3");
           playerHealth = 3;
        }
    }
    
        return playerHealth;
    }
    
    public void fall()
    {
       if(getY() >= 475){
            Greenfoot.playSound("Game Over.mp3");
            Greenfoot.setWorld(new GameOver());
        }
            
       setLocation(getX(), getY() + vSpeed);
       if(vSpeed <= 9)
       {   
           vSpeed = vSpeed + acceleration;
       }
       jumping = true;
       
    }
    
    public boolean onSpikes()
    {
        int sriteHeight = getImage().getHeight();
        int lookForGround = (int)(sriteHeight/2) + 5;
        Actor spikes= getOneObjectAtOffset(0,lookForGround,spikes.class);
        if(spikes == null)
        {
            return false;
        }
        else
        {
            Greenfoot.playSound("Game Over.mp3");
            Greenfoot.setWorld(new GameOver());
            return true;
        }
            
    }
    
    
    public boolean onGround()
    {
        int sriteHeight = getImage().getHeight();
        int lookForGround = (int)(sriteHeight/2) + 5;
        Actor ground = getOneObjectAtOffset(0,lookForGround,Ground.class);
        if(ground == null)
        {
            jumping = true;
            return false;
        }
        else
        {
            moveToGround(ground);
            return true;
        }
            
    }
    
    public boolean platformAbove()
    {
        int sriteHeight = getImage().getHeight();
        int yDistance = (int)(sriteHeight/ -2) ;
        Actor ceiling = getOneObjectAtOffset(0,yDistance, Ground.class);
        if(ceiling != null)
        {
            vSpeed  = 1;
            bopHead(ceiling);
            return true;
        }
        else
        {
            return false;
        }
            
    }
    
     public boolean checkRightSpikes()
    {
        int spriteWidth = getImage().getWidth();
        int xDistance = (int) (spriteWidth/2);
        Actor rightSpikes= getOneObjectAtOffset(xDistance, 0, spikes.class);
        if(rightSpikes == null)
        {
            return false;
        }
        else
        {
           Greenfoot.playSound("Game Over.mp3");
           Greenfoot.setWorld(new GameOver());
            return true;
        }
    }
    
    public void stopRightSpikes(Actor rightSpike)
    {
        int spikeWidth = rightSpike.getImage().getWidth();
        int newX = rightSpike.getX() - (spikeWidth + getImage().getWidth())/2;
    }
    
    public boolean checkRightWalls()
    {
        int spriteWidth = getImage().getWidth();
        int xDistance = (int) (spriteWidth/2);
        Actor rightWall = getOneObjectAtOffset(xDistance, 0, Ground.class);
        if(rightWall == null)
        {
            return false;
        }
        else
        {
            stopRightWall(rightWall);
            return true;
        }
    }
    
    public void stopRightWall(Actor rightWall)
    {
        int wallWidth = rightWall.getImage().getWidth();
        int newX = rightWall.getX() - (wallWidth + getImage().getWidth())/2;
        setLocation(newX -5, getY());
    }
    
    public boolean checkLeftSpikes()
    {
        int spriteWidth = getImage().getWidth();
        int xDistance = (int) (spriteWidth/-2);
        Actor leftSpikes = getOneObjectAtOffset(xDistance, 0, spikes.class);
        if(leftSpikes == null)
        {
            return false;
        }
        else
        {   
            Greenfoot.playSound("Game Over.mp3");
            Greenfoot.setWorld(new GameOver());
            return true;
        }
    }
    
     public void stopLeftSpikes(Actor leftSpikes)
    {
        int spikesWidth = leftSpikes.getImage().getWidth();
        int newX = leftSpikes.getX() + (spikesWidth + getImage().getWidth())/2;
        setLocation(newX + 5, getY());

    }
    
    public boolean checkLeftWalls()
    {
        int spriteWidth = getImage().getWidth();
        int xDistance = (int) (spriteWidth/-2);
        Actor leftWall = getOneObjectAtOffset(xDistance, 0, Ground.class);
        if(leftWall == null)
        {
            return false;
        }
        else
        {
            stopLeftWall(leftWall);
            return true;
        }
    }
    
    public void stopLeftWall(Actor leftWall)
    {
        int wallWidth = leftWall.getImage().getWidth();
        int newX = leftWall.getX() + (wallWidth + getImage().getWidth())/2;
        setLocation(newX + 5, getY());
    }
    
   
    
    public void moveToGround(Actor ground)
    {
        int groundHeight =ground.getImage().getHeight();
        int newY = ground.getY() - (groundHeight + getImage().getHeight())/2;
        setLocation(getX(), newY);
        jumping = false;
    }
    
    public void bopHead(Actor ceiling)
    {
        int ceilingHeight = ceiling.getImage().getHeight();
        int newY = ceiling.getY() + (ceilingHeight + getImage().getHeight())/2;
        
        setLocation(getX(), newY);
        
    }
    
 
    public void checkFall()
    {
        if(onGround())
        {
            vSpeed = 0;
        }
        else
        {
            fall();
        }
    }
    
    public void keyPressed(){
        if(Greenfoot.isKeyDown("space") && jumping == false){
            jump();
           Greenfoot.playSound("Sokinejimo.mp3");
        }
        
        if(Greenfoot.isKeyDown("right")){
            moveRight();
            direction = 1;
       }
        
        if(Greenfoot.isKeyDown("left")){
            direction = -1;
           // moveLeft();
        }
    }
    
    public void jump(){
        vSpeed = vSpeed - jumpStrength;
        jumping = true;
        fall();
        if(direction == 1)
            setImage(jump_right);
            
        if(direction == -1)
            setImage(jump_left);
        
        verticalSpeed = verticalSpeed - jumpStrength;
        jumping = true;
        fall();
    }
}
