import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level21 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level21 extends World
{

    /**
     * Constructor for objects of class level21.
     * 
     */
    public level21()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        ground2lvl ground2lvl = new ground2lvl();
        addObject(ground2lvl,450,469);

        MovingUp50 movingUp = new MovingUp50();
        addObject(movingUp,552,218);
        MovingUp50 movingUp2 = new MovingUp50();
        addObject(movingUp2,318,158);
        MovingUp50 movingUp3 = new MovingUp50();
        addObject(movingUp3,96,42);
        Pug pug = new Pug();
        addObject(pug,875,408);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,328,114);
        laikrastis laikrastis2 = new laikrastis();
        addObject(laikrastis2,549,170);
        movingUp3.setLocation(133,47);
        movingUp3.setLocation(127,80);
        removeObject(movingUp3);
        plonas plonas = new plonas();
        addObject(plonas,65,145);

        colider colider = new colider();
        addObject(colider,0,117);
        Health health = new Health();
        addObject(health,75,13);

        spikestrumpesni spikestrumpesni = new spikestrumpesni();
        addObject(spikestrumpesni,76,428);
        spikestrumpesni spikestrumpesni2 = new spikestrumpesni();
        addObject(spikestrumpesni2,232,428);
        spikestrumpesni spikestrumpesni3 = new spikestrumpesni();
        addObject(spikestrumpesni3,388,428);
        spikestrumpesni spikestrumpesni4 = new spikestrumpesni();
        addObject(spikestrumpesni4,544,428);
        plonas plonas2 = new plonas();
        addObject(plonas2,705,421);

        CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);

    }
}
