import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level28 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level28 extends World
{

    /**
     * Constructor for objects of class level28.
     * 
     */
    public level28()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        spikes spikes = new spikes();
        addObject(spikes,450,490);
        spikes900_down spikes900_down = new spikes900_down();
        addObject(spikes900_down,449,11);
        Health health = new Health();
        addObject(health,74,13);

        ground2lvl_mini ground2lvl_mini = new ground2lvl_mini();
        addObject(ground2lvl_mini,823,448);
        ground2lvl_mini ground2lvl_mini2 = new ground2lvl_mini();
        addObject(ground2lvl_mini2,667,389);
        ground2lvl_mini ground2lvl_mini3 = new ground2lvl_mini();
        addObject(ground2lvl_mini3,510,331);
        ground2lvl_mini ground2lvl_mini4 = new ground2lvl_mini();
        addObject(ground2lvl_mini4,352,273);
        ground2lvl_mini ground2lvl_mini5 = new ground2lvl_mini();
        addObject(ground2lvl_mini5,196,214);
        ground2lvl_mini ground2lvl_mini6 = new ground2lvl_mini();
        addObject(ground2lvl_mini6,40,155);
        Pug pug = new Pug();
        addObject(pug,878,388);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,695,330);
        laikrastis laikrastis2 = new laikrastis();
        addObject(laikrastis2,568,274);
        laikrastis laikrastis3 = new laikrastis();
        addObject(laikrastis3,320,214);
        laikrastis laikrastis4 = new laikrastis();
        addObject(laikrastis4,206,156);
        laikrastis laikrastis5 = new laikrastis();
        addObject(laikrastis5,29,98);
        removeObject(laikrastis5);
        removeObject(ground2lvl_mini6);

        plonas plonas = new plonas();
        addObject(plonas,76,436);

        CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);

        colider colider = new colider();
        addObject(colider,0,415);
    }
}
