import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Health here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Health extends Pug
{
    private GreenfootImage health3 = new GreenfootImage("tryskaulai.png");
    private GreenfootImage health2 = new GreenfootImage("dukaulai.png");
    private GreenfootImage health1 = new GreenfootImage("vienaskaulas.png");
    private GreenfootImage health0 = new GreenfootImage("nuliskaulu.png");
    
    /**
     * Act - do whatever the Health wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       setHealthImage();
    }
    
    public void setHealthImage(){
        if(playerHealth == 3){
            setImage(health3);
        }
        
        if(playerHealth == 2){
            setImage(health2);
        }
        
        if(playerHealth == 1){
            setImage(health1);
        }   
        
        if(playerHealth == 0){
            setImage(health1);
        } 
        
           
    } 
}
