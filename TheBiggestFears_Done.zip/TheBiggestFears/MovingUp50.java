import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class judanti here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MovingUp50 extends Ground
{
    /**
     * Act - do whatever the judanti wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int up = -1;
    private int down = 50;
    public void act() 
    {
        moveTile();
    }
    
    public void moveTile(){
        if(down > 0){
          setLocation(getX(), getY()+2);  
          down--;
        } else{ 
            if(up < 0){
                up = 50;
                down = -1;
            }
        }

        if(up > 0){
            setLocation(getX(), getY()-2); 
            up--;
        } else {
            if(down < 0){
                down = 50;
                up = -1;
            }
        }
    }
 }    

