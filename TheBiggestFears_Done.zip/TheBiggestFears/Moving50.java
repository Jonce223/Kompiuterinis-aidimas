import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Moving here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Moving50 extends Ground
{
   private int left = -50;
    private int right= 50;
    
    public void act() 
    {
       moveTile();
    }
    
    public void moveTile(){
        if(right > 0){
          setLocation(getX()+2, getY());  
          right--;
        } else{ 
            if(left < 0){
                left = 50;
                right = -50;
            }
        }

        if(left > 0){
            setLocation(getX()-2, getY()); 
            left--;
        } else {
            if(right < 0){
                right  = 50;
                left = -50;
            }
        }
    }   
}
