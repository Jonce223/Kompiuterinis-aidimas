import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class spikes900_down here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class spikes900_down extends spikes
{
    /**
     * Act - do whatever the spikes900_down wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
