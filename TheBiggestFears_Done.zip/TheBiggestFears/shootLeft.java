import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class shootLeft here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class shootLeft extends ShootingManager
{
    /**
     * Act - do whatever the shootLeft wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int shootingSpeed = 8;
    public void act() 
    {
        fly();
        killBadGuys();
    }
    
    public void fly()
    {
        setLocation(getX() - shootingSpeed, getY());
        
    }
}
