import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level31 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level31 extends World
{

    /**
     * Constructor for objects of class level31.
     * 
     */
    public level31()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        
        //showText("Score: "+ score, 85,30);
        Pug2 pug2 = new Pug2();
        addObject(pug2,441,420);

        CounterPinigas counterPinigas = new CounterPinigas();
        addObject(counterPinigas,48,26);
       
        ground3lvl ground3lvl = new ground3lvl();
        addObject(ground3lvl,450,471);
        ground3lvl.setLocation(450,471);
        pug2.setLocation(437,408);
}
    
    public void act(){
        if(Greenfoot.getRandomNumber(400)<2){
            addObject(new priesas1(), Greenfoot.getRandomNumber(900), 10);
        }
        if(Greenfoot.getRandomNumber(500)<2){
            addObject(new priesas2(), Greenfoot.getRandomNumber(900), 10);
        }   
        if(Greenfoot.getRandomNumber(400)<2){
            addObject(new priesas3(), Greenfoot.getRandomNumber(900), 10);
        }
        if(Greenfoot.getRandomNumber(300)<2){
            addObject(new pinigelis(), Greenfoot.getRandomNumber(900), 10);
        }
        if(Greenfoot.getRandomNumber(500)<2){
            addObject(new priesas4(), Greenfoot.getRandomNumber(900), 10);
        }
    }
    
   
}
