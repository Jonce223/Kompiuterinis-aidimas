import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level23 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level23 extends World
{

    /**
     * Constructor for objects of class level23.
     * 
     */
    public level23()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        spikes spikes = new spikes();
        addObject(spikes,449,488);
        plonas plonas = new plonas();
        addObject(plonas,822,145);
        MovingDown50 movingDown50 = new MovingDown50();
        addObject(movingDown50,616,233);
        MovingUp50 movingUp50 = new MovingUp50();
        addObject(movingUp50,368,155);

        Health health = new Health();
        addObject(health,77,18);
        
        Pug pug = new Pug();
        addObject(pug,886,97);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,600,185);
       

        plonas plonas1 = new plonas();
        addObject(plonas1,77,281);
        colider colider = new colider();
        addObject(colider,2,253);
       
        CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);
    }
}
