import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class colider here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class colider extends Actor
{
    public GreenfootSound soundtrack = new GreenfootSound("Naujamuzika.mp3");
    /**
     * Act - do whatever the colider wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        isColiding();
        playStop();
    }
    
    public void isColiding(){
        Actor player = getOneObjectAtOffset((int)getImage().getWidth()/2, 0, Pug.class);
        
       if(player != null){
            if(this.getWorld().getClass() == Start.class){
                Greenfoot.setWorld(new Level11());
            }
                
                
            if(this.getWorld().getClass() == Level11.class)
                Greenfoot.setWorld(new Level12());
            
            if(this.getWorld().getClass() == Level12.class)
                Greenfoot.setWorld(new Level13());
                
            if(this.getWorld().getClass() == Level13.class)
                Greenfoot.setWorld(new Level14());
                
            if(this.getWorld().getClass() == Level14.class)
                Greenfoot.setWorld(new Level1Laimejimas());   
                
            if(this.getWorld().getClass() == level21.class)
                Greenfoot.setWorld(new level22());
                
            if(this.getWorld().getClass() == level22.class)
                Greenfoot.setWorld(new level23());
                
            if(this.getWorld().getClass() == level23.class)
                Greenfoot.setWorld(new level24());
                
            if(this.getWorld().getClass() == level24.class)
                Greenfoot.setWorld(new level25());
            
            if(this.getWorld().getClass() == level25.class)
                Greenfoot.setWorld(new level26());
            
            if(this.getWorld().getClass() == level26.class)
                Greenfoot.setWorld(new level27());
            
            if(this.getWorld().getClass() == level27.class)
                Greenfoot.setWorld(new level28());
                
            if(this.getWorld().getClass() == level28.class)
                Greenfoot.setWorld(new Level2Laimejimas());
            
       }
      
    }  
    
    public void playStop(){
        if(this.getWorld().getClass() == Start.class){
               // soundtrack.play();
        }
        
        if(this.getWorld().getClass() == GameOver.class){
              if(soundtrack.isPlaying()){
                  soundtrack.stop();    
                }
        }
    
    }
}
