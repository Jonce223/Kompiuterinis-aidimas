import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MovingDown50 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MovingDown50 extends Ground
{
    /**
     * Act - do whatever the MovingDown50 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int up = 50;
    private int down = -1;
    public void act() 
    {
        moveTile();
    }
    
    public void moveTile(){
        if(down > 0){
          setLocation(getX(), getY()+2);  
          down--;
        } else{ 
            if(up < 0){
                up = 50;
                down = -1;
            }
        }

        if(up > 0){
            setLocation(getX(), getY()-2); 
            up--;
        } else {
            if(down < 0){
                down = 50;
                up = -1;
            }
        }
    }  
}
