import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level24 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level24 extends World
{

    /**
     * Constructor for objects of class level24.
     * 
     */
    public level24()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        spikes spikes = new spikes();
        addObject(spikes,449,489);

        plonas plonas = new plonas();
        addObject(plonas,824,210);

        plonas plonas2 = new plonas();
        addObject(plonas2,77,392);
        plonas plonas3 = new plonas();
        addObject(plonas3,648,280);
        plonas plonas4 = new plonas();
        addObject(plonas4,748,245);

        spikes80 spikes802 = new spikes80();
        addObject(spikes802,710,217);

        MovingDown50 movingDown50 = new MovingDown50();
        addObject(movingDown50,397,355);

        Pug pug = new Pug();
        addObject(pug,892,163);

        colider colider = new colider();
        addObject(colider,1,362);

        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,99,344);
        Health health = new Health();
        addObject(health,75,14);
         CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);
    }
}
