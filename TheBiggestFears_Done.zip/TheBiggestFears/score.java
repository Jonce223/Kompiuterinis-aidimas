import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class score here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class score extends World
{

    /**
     * Constructor for objects of class score.
     * 
     */
    static int score1 = 0;
    public score()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        
    }
    public static void skaiciavimas()
    {
        score1 -=5;
        if(score1 < 0){
            Greenfoot.setWorld(new GameOver());
        }
        if(score1 >=50){
            Greenfoot.setWorld(new Laimejimas());
        }
    }
    
}
