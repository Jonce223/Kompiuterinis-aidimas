import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level2Laimejimas here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level2Laimejimas extends World
{

    /**
     * Constructor for objects of class Level2Laimejimas.
     * 
     */
    public Level2Laimejimas()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
    }
}
