 import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
//public GreenfootSound soundtrack = new GreenfootSound("Pirmo lygio muzikele.mp3");
public class StartingWorld extends World
{
    public GreenfootSound soundtrack = new GreenfootSound("Pirmo lygio muzikele.mp3");
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public StartingWorld()
    {    
        // Create a new world with 900x500 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        //prepare();
    }
    
     public void act(){
        if(Greenfoot.isKeyDown("enter"))
        {
            Greenfoot.setWorld(new Start());
          
        } 
        
        

        
    }
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    
}
