import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level21 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level21 extends World
{

    /**
     * Constructor for objects of class level21.
     * 
     */
    public level21()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        ground2lvl ground2lvl = new ground2lvl();
        addObject(ground2lvl,450,469);

        MovingUp50 movingUp = new MovingUp50();
        addObject(movingUp,552,218);
        MovingUp50 movingUp2 = new MovingUp50();
        addObject(movingUp2,318,158);
        MovingUp50 movingUp3 = new MovingUp50();
        addObject(movingUp3,96,42);
        Pug pug = new Pug();
        addObject(pug,875,408);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,328,114);
        laikrastis laikrastis2 = new laikrastis();
        addObject(laikrastis2,549,170);
        movingUp3.setLocation(133,47);
        movingUp3.setLocation(127,80);
        removeObject(movingUp3);
        plonas plonas = new plonas();
        addObject(plonas,65,145);

        colider colider = new colider();
        addObject(colider,0,117);
    }
}
