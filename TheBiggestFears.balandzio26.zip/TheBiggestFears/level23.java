import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level23 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level23 extends World
{

    /**
     * Constructor for objects of class level23.
     * 
     */
    public level23()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
    }
}
