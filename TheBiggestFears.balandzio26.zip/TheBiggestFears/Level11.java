import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level11 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level11 extends World
{

    /**
     * Constructor for objects of class Level11.
     * 
     */
    public Level11()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }
    
    public void prepare()
    {
        Ground ground = new Ground();
        addObject(ground,450,477);
        ground250 ground250 = new ground250();
        addObject(ground250,776,122);
        ground250 ground2502 = new ground250();
        addObject(ground2502,458,264);
        Pug pug = new Pug();
        addObject(pug,865,62);
        ground250 ground2503 = new ground250();
        addObject(ground2503,247,357);
        ground250 ground2504 = new ground250();
        addObject(ground2504,592,418);
        Enemies enemies = new Enemies();
        addObject(enemies,364,196);
        Enemies enemies2 = new Enemies();
        addObject(enemies2,152,290);
        Enemies enemies3 = new Enemies();
        addObject(enemies3,689,350);
        colider colider = new colider();
        addObject(colider,3,429);
        CounterEnemies counter = new CounterEnemies();
        addObject(counter, 820, 29);
        Counter counter1 = new Counter();
        addObject(counter1, 858, 32);
    }
}
