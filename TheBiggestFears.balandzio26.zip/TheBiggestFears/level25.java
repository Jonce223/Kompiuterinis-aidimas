import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level25 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level25 extends World
{

    /**
     * Constructor for objects of class level25.
     * 
     */
    public level25()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
    }
}
