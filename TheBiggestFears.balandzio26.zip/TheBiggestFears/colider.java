import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class colider here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class colider extends Actor
{
    public GreenfootSound soundtrack = new GreenfootSound("Pirmo lygio muzikele.mp3");
    /**
     * Act - do whatever the colider wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        isColiding();
        playStop();
    }
    
    public void isColiding(){
        Actor player = getOneObjectAtOffset((int)getImage().getWidth()/2, 0, Pug.class);
        
       if(player != null){
            if(this.getWorld().getClass() == Start.class){
                Greenfoot.setWorld(new Level11());
            }
                
                
            if(this.getWorld().getClass() == Level11.class)
                Greenfoot.setWorld(new Level12());
            
            if(this.getWorld().getClass() == Level12.class)
                Greenfoot.setWorld(new Level13());
                
            if(this.getWorld().getClass() == Level13.class)
                Greenfoot.setWorld(new Level14());
                
            if(this.getWorld().getClass() == Level14.class)
                Greenfoot.setWorld(new Level1Laimejimas());    
       }
      
    }  
    
    public void playStop(){
        if(this.getWorld().getClass() == Start.class){
                soundtrack.play();
        }
        
        if(this.getWorld().getClass() == GameOver.class){
              if(soundtrack.isPlaying()){
                  soundtrack.stop();    
                }
        }
    
    }
}
