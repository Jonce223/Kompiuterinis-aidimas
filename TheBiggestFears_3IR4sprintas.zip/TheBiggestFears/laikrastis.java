import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class laikrastis here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class laikrastis extends BadGuy
{
    
    private int vSpeed = 0;
    private int acceleration = 2;
    private boolean jumping;
    private int speed = 1;
    
    private int spriteHeight = getImage().getHeight();
    private int spriteWidth = getImage().getWidth();
    private int lookForGroundDistance = (int)spriteHeight/2;
    private int lookForEdge = (int)spriteWidth/2;
    
    int frame = 0;
    private int animationCount = 0;
    
    GreenfootImage siurblysR = new GreenfootImage("laikrastisidesine.png");
    
    GreenfootImage siurblysL = new GreenfootImage("laikrastisikaire.png");
   
    /**
     * Act - do whatever the laikrastis wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        checkFall();
        move();
        
        if(speed < 0)
        {
            setImage(siurblysR);
        }
        else
        {
            setImage(siurblysL);
        }
    }  
    
    public void move()
    {
       Actor ground = getOneObjectAtOffset(lookForEdge,lookForGroundDistance, Ground.class);
       if(ground == null)
       {
           speed *= -1;
           lookForEdge *= -1;
           
       }
       else
       {
           move(speed);
           
       }
        
        
    }
    public void fall()
    {
       setLocation(getX(), getY() + vSpeed);
       if(vSpeed <= 9)
       {
           
          vSpeed = vSpeed + acceleration;
       }
       jumping = true;
       
    }
    
    public boolean onGround()
    {
        int sriteHeight = getImage().getHeight();
        int lookForGround = (int)(sriteHeight/2) + 5;
        Actor ground = getOneObjectAtOffset(0,lookForGround,Ground.class);
        if(ground == null)
        {
            jumping = true;
            return false;
        }
        else
        {
            moveToGround(ground);
            return true;
        }
            
    }
    
    public void moveToGround(Actor ground)
    {
        int groundHeight =ground.getImage().getHeight();
        int newY = ground.getY() - (groundHeight + getImage().getHeight())/2;
        setLocation(getX(), newY);
        jumping = false;
    }
    
    public void checkFall()
    {
        if(onGround())
        {
            vSpeed = 0;
        }
        else
        {
            fall();
        }
    }
}
