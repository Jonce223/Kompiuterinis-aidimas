import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class shottright here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class shootRight extends ShootingManager
{
    /**
     * Act - do whatever the shottright wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int shootingSpeed = 8;
    public void act() 
    {
        fly();
        killBadGuys();
    } 
    
    public void fly()
    {
        setLocation(getX() + shootingSpeed, getY());
        
    }
}
