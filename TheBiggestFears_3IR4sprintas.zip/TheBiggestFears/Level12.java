import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level12 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level12 extends World
{

    /**
     * Constructor for objects of class Level12.
     * 
     */
    public Level12()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Ground ground = new Ground();
        addObject(ground,450,473);
        ground250 ground250 = new ground250();
        addObject(ground250,468,348);
        Enemies enemies = new Enemies();
        addObject(enemies,571,410);
        Enemies enemies2 = new Enemies();
        addObject(enemies2,649,412);
        Enemies enemies3 = new Enemies();
        addObject(enemies3,326,412);
        Enemies enemies4 = new Enemies();
        addObject(enemies4,161,411);
        Enemies enemies5 = new Enemies();
        addObject(enemies5,440,411);
        Enemies enemies6 = new Enemies();
        addObject(enemies6,353,286);
        Enemies enemies7 = new Enemies();
        addObject(enemies7,522,288);
        ground250 ground2502 = new ground250();
        addObject(ground2502,199,258);
        ground100 ground100 = new ground100();
        addObject(ground100,48,163);
        Enemies enemies8 = new Enemies();
        addObject(enemies8,124,195);
        Enemies enemies9 = new Enemies();
        addObject(enemies9,45,103);

        colider colider = new colider();
        addObject(colider,1,121);
        Pug pug = new Pug();
        addObject(pug,884,420);
        CounterEnemies counter = new CounterEnemies();
        addObject(counter, 820, 29);
        Counter counter1 = new Counter();
        addObject(counter1, 858, 32);
    }
}
