import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Start here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Start extends World
{
    Counter counter = new Counter();
    /**
     * Constructor for objects of class Start.
     * 
     */
    public Start()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Ground ground = new Ground();
        addObject(ground,450,475);
        ground500 ground500 = new ground500();
        addObject(ground500,651,354);
        ground250 ground250 = new ground250();
        addObject(ground250,776,219);
        ground250 ground2502 = new ground250();
        addObject(ground2502,442,124);
        ground250 ground2503 = new ground250();
        addObject(ground2503,120,112);
        colider colider = new colider();
        addObject(colider,1,64);
        Pug pug = new Pug();
        addObject(pug,28,422);
        CounterEnemies counter = new CounterEnemies();
        addObject(counter, 820, 29);
        Counter counter1 = new Counter();
        addObject(counter1, 858, 32);
        Enemies enemies3 = new Enemies();
        addObject(enemies3,689,350);
    }
}
