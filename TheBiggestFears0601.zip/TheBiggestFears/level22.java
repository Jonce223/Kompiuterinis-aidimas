import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level22 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level22 extends World
{

    /**
     * Constructor for objects of class level22.
     * 
     */
    public level22()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        plonas plonas = new plonas();
        addObject(plonas,823,145);
        spikes spikes = new spikes();
        addObject(spikes,449,489);
        Pug pug = new Pug();
        addObject(pug,894,98);
        plonas plonas2 = new plonas();
        addObject(plonas2,642,240);
        Moving50 moving50 = new Moving50();
        addObject(moving50,314,248);
        plonas plonas3 = new plonas();
        addObject(plonas3,77,171);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,54,124);
        colider colider = new colider();
        addObject(colider,1,140);
       
        Health health = new Health();
        addObject(health,74,13);
      
        
        CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);
    }
}
