import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level14 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level14 extends World
{

    /**
     * Constructor for objects of class Level14.
     * 
     */
    public Level14()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        ground100 ground100 = new ground100();
        addObject(ground100,854,189);
        ground100 ground1002 = new ground100();
        addObject(ground1002,721,248);
        ground100 ground1003 = new ground100();
        addObject(ground1003,580,185);
        ground100 ground1004 = new ground100();
        addObject(ground1004,414,184);
        ground100 ground1005 = new ground100();
        addObject(ground1005,243,362);
        
        ground100 ground1006 = new ground100();
        addObject(ground1006,138,272);
        ground100 ground1007 = new ground100();
        addObject(ground1007,45, 174);
        
        colider colider2 = new colider();
        addObject(colider2,2,146);
        Pug pug = new Pug();
        addObject(pug,891,128);

        Enemies enemies = new Enemies();
        addObject(enemies,566,118);
        
        Enemies enemies2 = new Enemies();
        addObject(enemies2,139,212);
        
        Enemies enemies3 = new Enemies();
        addObject(enemies3,60,113);
        CounterEnemies counter = new CounterEnemies();
        addObject(counter, 820, 29);
        Counter counter1 = new Counter();
        addObject(counter1, 858, 32);
        Health health = new Health();
        addObject(health,75,13);

    }
}
