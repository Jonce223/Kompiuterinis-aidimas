import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class pinigelis here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class pinigelis extends Actor
{
    /**
     * Act - do whatever the pinigelis wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        setLocation(getX(), getY()+5);
        pinigas();
    }
     public void pinigas(){
        Actor pug = getOneIntersectingObject(Pug2.class);
        if(pug !=null){
            getWorld().removeObject(this);
            score.score1 +=5;
            if(score.score1 >=50){
                        Greenfoot.setWorld(new Laimejimas());
        }
            
        }
        else if(isAtEdge()){
            getWorld().removeObject(this);
        }
    }
}
