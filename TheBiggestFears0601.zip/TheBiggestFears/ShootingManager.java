import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ShootingManager here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ShootingManager extends Actor
{
    public static int score = 0;
    
    public void act() 
    {
        killBadGuys();
    }
    
    public void remove()
    {
        Actor walls = getOneIntersectingObject(Ground.class);
        
        if(getX() <= 1 || getX() >= getWorld().getWidth()-1)
        {
            World myWorld = getWorld();
            myWorld.removeObject(this);
        }
        else if(walls != null)
        {
            
            getWorld().removeObject(this);
        }
     
    }
    
    public boolean amIshot(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0,0,clss);
        return actor != null;
    }
    
    public void kill(Class clss)
    {
        Actor actor = getOneObjectAtOffset(0,0,clss);
        if(actor != null)
        {
            getWorld().removeObject(actor);
            score++;  
            
        }
        
    }
    
    public void killBadGuys()
    {
        if(amIshot(BadGuy.class))
        {
            kill(BadGuy.class);
            getWorld().removeObject(this);
        }
        else
        {
            remove();
        }
    }
    
    
}
