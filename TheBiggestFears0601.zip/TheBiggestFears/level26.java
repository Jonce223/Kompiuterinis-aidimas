import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level26 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level26 extends World
{

    /**
     * Constructor for objects of class level26.
     * 
     */
    public level26()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        spikes900_down spikes900_down = new spikes900_down();
        addObject(spikes900_down,449,10);
        Health health = new Health();
        addObject(health,75,13);
        CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);
        plonas plonas = new plonas();
        addObject(plonas,825,224);
        spikes spikes = new spikes();
        addObject(spikes,450,489);
        plonas plonas2 = new plonas();
        addObject(plonas2,606,150);
        plonas plonas3 = new plonas();
        addObject(plonas3,364,256);
        plonas plonas4 = new plonas();
        addObject(plonas4,77,406);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,339,208);
        laikrastis laikrastis2 = new laikrastis();
        addObject(laikrastis2,54,362);
        colider colider = new colider();
        addObject(colider,2,380);
        Pug pug = new Pug();
        addObject(pug,886,177);
      
    }
}
