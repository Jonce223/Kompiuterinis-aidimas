import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class level25 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class level25 extends World
{

    /**
     * Constructor for objects of class level25.
     * 
     */
    public level25()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        spikes900_down spikes900_down = new spikes900_down();
        addObject(spikes900_down,449,12);
        spikes spikes = new spikes();
        addObject(spikes,447,488);
        Health health = new Health();
        addObject(health,77,17);
       
        plonas plonas = new plonas();
        addObject(plonas,824,392);
        plonas plonas2 = new plonas();
        addObject(plonas2,562,378);
        plonas plonas3 = new plonas();
        addObject(plonas3,352,280);
        plonas plonas4 = new plonas();
        addObject(plonas4,77,224);
        laikrastis laikrastis = new laikrastis();
        addObject(laikrastis,508,332);
        laikrastis laikrastis2 = new laikrastis();
        addObject(laikrastis2,283,233);
        laikrastis laikrastis3 = new laikrastis();
        addObject(laikrastis3,414,235);
        laikrastis laikrastis4 = new laikrastis();
        addObject(laikrastis4,34,176);
        colider colider = new colider();
        addObject(colider,2,198);
        Pug pug = new Pug();
        addObject(pug,884,347);
        
        CounterLaikrastis counterLaikrastis = new CounterLaikrastis();
        addObject(counterLaikrastis,820, 29);
        Counter counter = new Counter();
        addObject(counter,858, 32);
    }
}
