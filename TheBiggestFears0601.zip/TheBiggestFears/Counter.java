import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


/**
 * Write a description of class counter here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Counter extends ShootingManager
{
    /**
     * Act - do whatever the counter wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
      if(this.getWorld().getClass() == Start.class || this.getWorld().getClass() == Level11.class || this.getWorld().getClass() == Level12.class ||
      this.getWorld().getClass() == Level13.class || this.getWorld().getClass() == Level14.class )
      {
            setImage(new GreenfootImage("" + score, 24, Color.BLACK, new Color(56, 186, 148)  ));
      }
      if(this.getWorld().getClass() == level21.class || this.getWorld().getClass() == level22.class || this.getWorld().getClass() == level23.class ||
      this.getWorld().getClass() == level24.class || this.getWorld().getClass() == level25.class || this.getWorld().getClass() == level26.class
      || this.getWorld().getClass() == level27.class || this.getWorld().getClass() == level28.class)
      {
            setImage(new GreenfootImage("" + score, 24, Color.BLACK, new Color(64, 33, 80)  ));
      }
      if(this.getWorld().getClass()==level31.class){
          setImage(new GreenfootImage("" + score, 24, Color.BLACK, new Color(134, 255, 118)));
        }
    }    
    
 
}
