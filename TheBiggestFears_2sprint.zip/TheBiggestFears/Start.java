import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Start here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Start extends World
{

    /**
     * Constructor for objects of class Start.
     * 
     */
    public Start()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {

        Ground ground = new Ground();
        addObject(ground,450,475);
        ground500 ground500 = new ground500();
        addObject(ground500,651,354);
        ground250 ground250 = new ground250();
        addObject(ground250,776,219);
        ground250 ground2502 = new ground250();
        addObject(ground2502,442,124);
        ground250 ground2503 = new ground250();
        addObject(ground2503,120,112);
        Pug pug = new Pug();
        addObject(pug,46,417);

        colider colider = new colider();
        addObject(colider,1,64);
    }
}
