import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Level12 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Level12 extends World
{

    /**
     * Constructor for objects of class Level12.
     * 
     */
    public Level12()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(900, 500, 1); 
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Ground ground = new Ground();
        addObject(ground,498,462);
        Enemies enemies = new Enemies();
        addObject(enemies,169,406);
        Enemies enemies2 = new Enemies();
        addObject(enemies2,368,409);
        Enemies enemies3 = new Enemies();
        addObject(enemies3,566,411);
        Enemies enemies4 = new Enemies();
        addObject(enemies4,450,410);
        Enemies enemies5 = new Enemies();
        addObject(enemies5,261,410);
        ground250 ground250 = new ground250();
        addObject(ground250,500,340);
        ground250 ground2502 = new ground250();
        addObject(ground2502,221,270);
        ground250 ground2503 = new ground250();
        addObject(ground2503,37,174);
        Enemies enemies6 = new Enemies();
        addObject(enemies6,431,272);
        Enemies enemies7 = new Enemies();
        addObject(enemies7,223,199);
        Enemies enemies8 = new Enemies();
        addObject(enemies8,66,106);
        Pug pug = new Pug();
        addObject(pug,882,415);
        pug.setLocation(849,396);
        colider colider = new colider();
        addObject(colider,1,135);

    }
}
